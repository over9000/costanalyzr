#!/bin/sh
sh tomcat/bin/shutdown.sh &&
echo "CostAnalyzR wurde beendet."
