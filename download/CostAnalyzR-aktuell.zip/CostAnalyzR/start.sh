#!/bin/sh
sh tomcat/bin/startup.sh &&
echo "CostAnalyzR wird gestartet. Bitte warten Sie einen kleinen Moment \nund öffnen Sie dann den Webbrowser mit der Adresse http://127.0.01:8080."
